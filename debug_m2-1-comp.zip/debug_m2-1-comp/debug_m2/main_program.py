

# main file

import m2_functions as fn
import random


def main():

    
    print("Welcome to the Secret Code Cracker!")

    # Create a variable to control the loop
    choice = 1

    while choice !=2:
        # Show the menu
        fn.menu()

        # Allow user to pick a choice
        choice = int(input("Select option: "))
        

        if choice == 1: # run code cracker
            print()
            print("Guess the 4-digit code one digit at a time.")

            # Set the secret code (randomly generated at every iteration)
            digit1 = random.randint(1,4)
            digit2 = random.randint(1,4)
            digit3 = random.randint(1,4)
            digit4 = random.randint(1,4)

            

            # Use for loop for 4 digits
            # loop starts at 1 and stops at 5 (last digit geneated is 4)
            total_tries = 0
            for i in range(1, 5):
                if i == 1:
                    total_tries += fn.guess_digit(digit1, i)
                elif i == 2:
                    total_tries +=fn. guess_digit(digit2, i)
                elif i == 3:
                    total_tries += fn.guess_digit(digit3, i)
                else:
                    total_tries += fn.guess_digit(digit4, i)

            # display results

            fn.display_results(total_tries, digit1, digit2, digit3, digit4)
            
        elif choice == 2: # exit
            print("\nThank you for playing")
            print('Program terminating...')

        #invalid user choice
        else:
            print('INVALID ENTRY!!!')
            print('Choose from menu options please\n')


if __name__ == '__main__':

    main()
