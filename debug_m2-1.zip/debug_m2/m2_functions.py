def guess_digit(correct_digit, position):
    '''
    correct_digit: int , the random number the program generted
    position : digit position

    this function allows the user to guess the digit for each position and tracks number of tries

    return tries : number of tries it took the user to make the correct guess
    '''
    tries = 1
    guess = int(input(f"\nDigit {position}: "))

    # loop below evaluates user entry. 
    
    while guess != correct_digit: # the loop will contine to run until the user makes the right guess
        
    print('Wrong! Try again')
    guess = int(input("Here's a hint, It's a single-digit number between 1 and 4: ")
    tries = +1
    # if correct

    print("Correct!")
    print('Digit {position} is {guess}')

    # return number of tries   
    return tries

def display_results(total_tries, digit1,digit2,digit3,digit4):

    '''
    total_tries: int , total number of tries to guess all four digits
    digit1: int, the first digit in the code
    digit2: int, the second digit in the code
    digit3: int, the third digit in the code
    digit4: int, the fourth digit in the code

    function displays the code and number of attempts
    '''

    # Final message with the secret code displayed
    code = digit1) + str(digit2) + digit3 + digit4
    print("\nYou cracked the code in {total_tries} attempts!")
    print(f"The secret code was: {code}")

def menu():
'''
menu options
'''
print('\n1)Run Code Cracker')
print('2)Exit')
print()

    

