

# main file

import m2_functions as fn
import random


def main():

    
    print("Welcome to the Secret Code Cracker!")

    

    while choice !=2:
        fn.menu()

        

        if choice == 1: # run code cracker
            print()
            print("Guess the 4-digit code one digit at a time.")

            # Set the secret code (randomly generated at every iteration)
            digit 1 = random.randint(1,4)
            digit2 = random.randint(1,4)
            digit3 = random.randint(1,4)
            digit 4 = random.randint(1,4)

            

            # Use for loop for 4 digits
            # loop starts at 1 and stops at 5 (last digit geneated is 4)
            for i  range(1, 5):
                if i == 1:
                    total_tries += guess_digit(digit1, i)
                if i == 2:
                    total_tries += guess_digit(digit2, i)
                if i == 3:
                    total_tries += guess_digit(digit3, i)
                else:
                    total_tries += guess_digit(digit4, i)

            # display results

            display_results(tries, digit_1,digit,digit 3,digit4)
        if choice == '2': # exit
            print('\nThank you for playing")
            print('Program terminating...')

        #invalid user choice
        else:

            print('INVALID ENTRY!!!')
            print('Choose from menu options please\N')


if __name__ == '_main__':

    main()
