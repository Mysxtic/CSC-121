# Dayvion Peoples
# 3/3/2026
# M5LAB
# Reading from csv file

import csv

def main():
    # Open the file
    with open("sales.csv", "r") as file:
        # Create a reader object
        reader = csv.DictReader(file)
        
        # Determine all valid product ids from csv file
        valid_products = []
        for row in reader:
            if row['prodID'] not in valid_products:
                valid_products.append(row["prodID"])
        
        
        # Each row is turned into its own dictionary
        units = 0
        for i in valid_products:
            for row in reader:
                if i ==["prodID"]:
                    units += row['units']
            total_sales = units * row['price']
            print(f"{row['prodID']}{total_sales}")
                    
            


# Call the main
if __name__ == "__main__":
    main()