# Dayvion Peoples
# 3/3/2026
# M5LAB
# Reading from csv file

import csv

def main():
    # Open the file
    with open("sales.csv", "r") as file:
        # Create a reader object
        reader = csv.DictReader(file)
        # Convert reader (data from file) to a list
        rows = list(reader)
        print(rows)
        
        
        # Determine all valid product ids from csv file
        valid_products = []
        for dictionary in rows:
            if dictionary['prodID'] not in valid_products:
                valid_products.append(dictionary["prodID"])
        print(valid_products)
        
        
        # Each row is turned into its own dictionary
        # Reader is a collection of dictionaries
        units = 0
        for i in valid_products:
            #print(f" the value of i is {i}")
            for row in rows:
                if i ==["prodID"]:
                    units += int(row['units'])
            total_sales = units * float(row['price'])
            
            # Everytime before i changes
            print(f"Product ID: {i} Total Sales for Product {i}: ${total_sales:.2f} ")
            
        
            
            print(f"{row['prodID']}{total_sales}")

    with open("total_sales.csv", "w", newline="") as file:
        fieldnames = ["ProdID", "Total Sales"]
        
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        
        
        writer.writeheader()
        
        
        # loop through the list of dictionaries
        for each in list_to_write:
            writer.writerow(each)


# Call the main
if __name__ == "__main__":
    main()